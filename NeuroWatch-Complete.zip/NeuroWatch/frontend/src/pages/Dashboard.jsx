import React from "react";
import HeatMap from "../components/HeatMap";
import RiskGauge from "../components/RiskGauge";
import VenueMap from "../components/VenueMap";
import RescuePanel from "../components/RescuePanel";
import AlertFeed from "../components/AlertFeed";
import AnnouncementBanner from "../components/AnnouncementBanner";
import { useNeuroWatch } from "../components/NeuroWatchContext";

const SCENARIOS = [
  { id: "normal", label: "Normal" },
  { id: "kumbh_surge", label: "Kumbh Surge" },
  { id: "crush", label: "Crush Scenario" },
];

export default function Dashboard() {
  const { data, scenario, setScenario, connected, alerts } = useNeuroWatch();

  return (
    <div className="dashboard">
      {/* Top bar */}
      <header className="topbar">
        <div className="topbar-left">
          <span className="logo">🧠 NeuroWatch</span>
          <span className="logo-sub">Neuromorphic Crowd Safety Monitor</span>
        </div>
        <div className="topbar-right">
          <span className={`conn-status ${connected ? "live" : "sim"}`}>
            <span className="conn-dot" />
            {connected ? "Live Backend" : "Simulation Mode"}
          </span>
          <span className="timestamp font-mono">{data.timestamp}</span>
        </div>
      </header>

      {/* Scenario buttons */}
      <div className="scenario-bar">
        {SCENARIOS.map((s) => (
          <button
            key={s.id}
            className={`scenario-btn ${scenario === s.id ? "active" : ""}`}
            onClick={() => setScenario(s.id)}
          >
            {s.label}
          </button>
        ))}
      </div>

      {/* Announcement banner (auto-shows when risk > 75) */}
      <AnnouncementBanner risk={data.risk} announcement={data.rescue?.announcement} />

      {/* Main grid: HeatMap | RiskGauge+Stats */}
      <div className="main-grid">
        <div className="col-main">
          <HeatMap grid={data.spikeGrid} />
          <VenueMap spikeGrid={data.spikeGrid} dangerZone={data.dangerZone} rescue={data.rescue} />
        </div>

        <div className="col-side">
          <RiskGauge risk={data.risk} status={data.status} />

          <div className="stats-card card">
            <div className="stats-title">📈 Neuromorphic Metrics</div>
            <div className="stats-row">
              <span>Spike Density</span>
              <span className="font-mono">{(data.spikeDensity * 100).toFixed(1)}%</span>
            </div>
            <div className="stats-row">
              <span>Flow Variance</span>
              <span className="font-mono">{(data.flowVariance * 100).toFixed(1)}%</span>
            </div>
            <div className="stats-row">
              <span>Spike Rate</span>
              <span className="font-mono">{(data.spikeRate * 100).toFixed(1)}%</span>
            </div>
          </div>

          <RescuePanel rescue={data.rescue} victim={data.victim} />
        </div>
      </div>

      {/* Alert feed */}
      <div className="alert-feed-wrapper">
        <AlertFeed alerts={alerts} maxItems={8} />
      </div>

      <style>{`
        .dashboard {
          padding: 20px;
          max-width: 1400px;
          margin: 0 auto;
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .topbar {
          display: flex;
          justify-content: space-between;
          align-items: center;
          flex-wrap: wrap;
          gap: 10px;
          padding-bottom: 4px;
        }
        .topbar-left {
          display: flex;
          align-items: baseline;
          gap: 12px;
          flex-wrap: wrap;
        }
        .logo { font-size: 22px; font-weight: 800; }
        .logo-sub { font-size: 12px; color: var(--text-secondary); }
        .topbar-right {
          display: flex;
          align-items: center;
          gap: 14px;
        }
        .conn-status {
          display: flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
          font-family: var(--font-mono);
          padding: 4px 12px;
          border-radius: 999px;
          border: 1px solid var(--border-subtle);
        }
        .conn-status.live { color: var(--color-safe); border-color: var(--color-safe); }
        .conn-status.sim { color: var(--text-secondary); }
        .conn-dot {
          width: 8px; height: 8px; border-radius: 50%;
          background: currentColor;
          animation: blink 1.5s infinite;
        }
        .timestamp { font-size: 13px; color: var(--text-secondary); }

        .scenario-bar {
          display: flex;
          gap: 10px;
          flex-wrap: wrap;
        }
        .scenario-btn {
          background: var(--bg-panel);
          border: 1px solid var(--border-subtle);
          color: var(--text-secondary);
          padding: 8px 18px;
          border-radius: 999px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: all 0.15s;
        }
        .scenario-btn:hover {
          border-color: rgba(255,255,255,0.2);
          color: var(--text-primary);
        }
        .scenario-btn.active {
          background: rgba(57,255,136,0.1);
          border-color: var(--color-safe);
          color: var(--color-safe);
        }

        .main-grid {
          display: grid;
          grid-template-columns: 1.6fr 1fr;
          gap: 16px;
          align-items: start;
        }
        .col-main {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }
        .col-side {
          display: flex;
          flex-direction: column;
          gap: 16px;
        }

        .stats-card {
          display: flex;
          flex-direction: column;
          gap: 6px;
        }
        .stats-title {
          font-weight: 600;
          font-size: 14px;
          margin-bottom: 6px;
        }
        .stats-row {
          display: flex;
          justify-content: space-between;
          font-size: 13px;
          color: var(--text-secondary);
          padding: 4px 0;
          border-bottom: 1px solid rgba(255,255,255,0.04);
        }
        .stats-row:last-child { border-bottom: none; }
        .stats-row span:last-child { color: var(--text-primary); font-weight: 600; }

        .alert-feed-wrapper {
          height: 260px;
        }

        @media (max-width: 900px) {
          .main-grid { grid-template-columns: 1fr; }
        }
      `}</style>
    </div>
  );
}
