import React, { useState, useMemo } from "react";

/**
 * AlertsPage.jsx
 * Props:
 *  - alerts: same shape as AlertFeed
 *  - onClear: () => void
 */

const SEVERITIES = ["ALL", "SAFE", "CAUTION", "WARNING", "HIGH RISK", "EMERGENCY"];

const STATUS_STYLES = {
  SAFE:        { color: "#39ff88", bg: "rgba(57,255,136,0.08)",  border: "rgba(57,255,136,0.3)" },
  CAUTION:     { color: "#ffd93d", bg: "rgba(255,217,61,0.08)",  border: "rgba(255,217,61,0.3)" },
  WARNING:     { color: "#ff9f1c", bg: "rgba(255,159,28,0.1)",   border: "rgba(255,159,28,0.35)" },
  "HIGH RISK": { color: "#ff5050", bg: "rgba(255,80,80,0.1)",    border: "rgba(255,80,80,0.35)" },
  EMERGENCY:   { color: "#ff1f3d", bg: "rgba(255,31,61,0.14)",   border: "rgba(255,31,61,0.5)" },
};

export default function AlertsPage({ alerts = [], onClear }) {
  const [filter, setFilter] = useState("ALL");

  const filtered = useMemo(() => {
    if (filter === "ALL") return alerts;
    return alerts.filter((a) => a.status === filter);
  }, [alerts, filter]);

  return (
    <div className="alerts-page">
      <div className="alerts-page-header">
        <div>
          <h1 className="alerts-title">🚨 Alert History</h1>
          <p className="alerts-subtitle">Full log of risk events detected by NeuroWatch</p>
        </div>
        <button className="clear-btn" onClick={onClear}>
          🗑️ Clear Alerts
        </button>
      </div>

      <div className="filter-bar">
        {SEVERITIES.map((s) => (
          <button
            key={s}
            className={`filter-chip ${filter === s ? "active" : ""}`}
            onClick={() => setFilter(s)}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="alerts-table-wrapper">
        <table className="alerts-table">
          <thead>
            <tr>
              <th>Time</th>
              <th>Status</th>
              <th>Zone</th>
              <th>Risk %</th>
              <th>Message</th>
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 && (
              <tr>
                <td colSpan="5" className="empty-row">
                  No alerts match this filter.
                </td>
              </tr>
            )}
            {filtered.map((a) => {
              const style = STATUS_STYLES[a.status] || STATUS_STYLES.SAFE;
              return (
                <tr key={a.id}>
                  <td className="mono">{a.timestamp}</td>
                  <td>
                    <span
                      className="status-pill"
                      style={{ color: style.color, borderColor: style.color, background: style.bg }}
                    >
                      {a.status}
                    </span>
                  </td>
                  <td className="mono">{a.zone || "—"}</td>
                  <td className="mono" style={{ color: style.color, fontWeight: 700 }}>
                    {a.risk}%
                  </td>
                  <td>{a.message}</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      <style>{`
        .alerts-page {
          padding: 24px;
          color: #e6edf3;
          font-family: 'Inter', sans-serif;
          max-width: 1100px;
          margin: 0 auto;
        }
        .alerts-page-header {
          display: flex;
          justify-content: space-between;
          align-items: flex-start;
          margin-bottom: 18px;
          flex-wrap: wrap;
          gap: 12px;
        }
        .alerts-title { font-size: 26px; font-weight: 700; margin: 0; }
        .alerts-subtitle { color: #9fb3c8; font-size: 13px; margin: 4px 0 0 0; }
        .clear-btn {
          background: rgba(255,80,80,0.1);
          border: 1px solid rgba(255,80,80,0.35);
          color: #ff8a8a;
          padding: 8px 16px;
          border-radius: 8px;
          font-size: 13px;
          font-weight: 600;
          cursor: pointer;
          transition: background 0.2s;
        }
        .clear-btn:hover { background: rgba(255,80,80,0.2); }

        .filter-bar {
          display: flex;
          gap: 8px;
          margin-bottom: 16px;
          flex-wrap: wrap;
        }
        .filter-chip {
          background: #11151f;
          border: 1px solid rgba(255,255,255,0.1);
          color: #9fb3c8;
          padding: 6px 14px;
          border-radius: 999px;
          font-size: 12px;
          font-family: 'JetBrains Mono', monospace;
          cursor: pointer;
          transition: all 0.15s;
        }
        .filter-chip.active {
          background: rgba(57,255,136,0.1);
          border-color: #39ff88;
          color: #39ff88;
        }

        .alerts-table-wrapper {
          background: #11151f;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 14px;
          overflow: hidden;
        }
        .alerts-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 13px;
        }
        .alerts-table th {
          text-align: left;
          padding: 12px 14px;
          color: #9fb3c8;
          font-size: 11px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
          border-bottom: 1px solid rgba(255,255,255,0.08);
        }
        .alerts-table td {
          padding: 10px 14px;
          border-bottom: 1px solid rgba(255,255,255,0.04);
          vertical-align: top;
        }
        .alerts-table tr:last-child td { border-bottom: none; }
        .mono { font-family: 'JetBrains Mono', monospace; }
        .status-pill {
          font-family: 'JetBrains Mono', monospace;
          font-size: 10px;
          font-weight: 700;
          border: 1px solid;
          border-radius: 999px;
          padding: 2px 10px;
          letter-spacing: 0.5px;
          white-space: nowrap;
        }
        .empty-row {
          text-align: center;
          color: #6b7d91;
          padding: 32px 0 !important;
        }
      `}</style>
    </div>
  );
}
