import React, { useMemo } from "react";
import venueLayout from "../../../data/venue_layout.json";

/**
 * VenueMap.jsx
 * SVG-based top-down venue layout.
 * Props:
 *  - spikeGrid: 10x10 array (0..1) of spike intensities from backend
 *  - dangerZone: string | null  e.g. "C4"
 *  - rescue: { zone, route, exitGate } | null
 */

const GRID = 10;
const CELL = 50; // px per grid cell
const SVG_SIZE = GRID * CELL; // 500x500

function intensityToColor(v) {
  // 0 -> blue, 0.5 -> yellow, 1 -> red
  if (v < 0.5) {
    const t = v / 0.5;
    const r = Math.round(30 + t * (255 - 30));
    const g = Math.round(60 + t * (220 - 60));
    const b = Math.round(200 - t * 160);
    return `rgb(${r},${g},${b})`;
  } else {
    const t = (v - 0.5) / 0.5;
    const r = 255;
    const g = Math.round(220 - t * 220);
    const b = Math.round(40 - t * 40);
    return `rgb(${r},${g},${b})`;
  }
}

function zoneToCell(zoneId) {
  const zone = venueLayout.zones.find((z) => z.id === zoneId);
  return zone ? { row: zone.row, col: zone.col } : null;
}

export default function VenueMap({ spikeGrid, dangerZone, rescue }) {
  const grid = spikeGrid && spikeGrid.length === GRID
    ? spikeGrid
    : Array.from({ length: GRID }, () => Array.from({ length: GRID }, () => 0));

  const dangerCell = useMemo(() => (dangerZone ? zoneToCell(dangerZone) : null), [dangerZone]);

  const routeKey = rescue?.route || rescue?.zoneRoute;
  const routeDef = routeKey ? venueLayout.routes[routeKey] : null;

  const pathD = useMemo(() => {
    if (!routeDef || !routeDef.path?.length) return null;
    const pts = routeDef.path;
    let d = `M ${pts[0].x} ${pts[0].y}`;
    for (let i = 1; i < pts.length; i++) d += ` L ${pts[i].x} ${pts[i].y}`;
    return d;
  }, [routeDef]);

  return (
    <div className="venue-map-wrapper">
      <div className="venue-map-header">
        <span className="venue-title">🗺️ Venue Map — {venueLayout.venueName}</span>
        {dangerZone && (
          <span className="danger-badge">⚠ DANGER ZONE: {dangerZone}</span>
        )}
      </div>

      <svg
        viewBox={`0 0 ${SVG_SIZE} ${SVG_SIZE}`}
        className="venue-svg"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background */}
        <rect x="0" y="0" width={SVG_SIZE} height={SVG_SIZE} fill="#0b0f1a" rx="8" />

        {/* Spike intensity grid */}
        {grid.map((rowArr, r) =>
          rowArr.map((val, c) => (
            <rect
              key={`cell-${r}-${c}`}
              x={c * CELL}
              y={r * CELL}
              width={CELL}
              height={CELL}
              fill={intensityToColor(val)}
              opacity={0.35 + val * 0.45}
              stroke="rgba(255,255,255,0.04)"
              className={val > 0.7 ? "cell-pulse" : ""}
            />
          ))
        )}

        {/* Structures */}
        {venueLayout.structures.map((s) => (
          <g key={s.id}>
            <rect
              x={s.x}
              y={s.y}
              width={s.width}
              height={s.height}
              fill="rgba(255,255,255,0.05)"
              stroke="rgba(255,255,255,0.25)"
              strokeWidth="1.5"
              rx="6"
            />
            <text
              x={s.x + s.width / 2}
              y={s.y + s.height / 2}
              fill="#cfd8e3"
              fontSize="11"
              fontFamily="Inter, sans-serif"
              textAnchor="middle"
              dominantBaseline="middle"
              pointerEvents="none"
            >
              {s.label}
            </text>
          </g>
        ))}

        {/* Danger zone highlight */}
        {dangerCell && (
          <rect
            x={dangerCell.col * CELL}
            y={dangerCell.row * CELL}
            width={CELL}
            height={CELL}
            fill="none"
            stroke="#ff3b3b"
            strokeWidth="4"
            rx="4"
            className="danger-glow"
          />
        )}

        {/* Rescue route */}
        {pathD && (
          <>
            <path
              d={pathD}
              fill="none"
              stroke="#39ff88"
              strokeWidth="4"
              strokeDasharray="10 6"
              className="route-dash"
            />
            {routeDef.path.map((p, i) => (
              <circle key={i} cx={p.x} cy={p.y} r="6" fill="#39ff88" />
            ))}
          </>
        )}

        {/* Gates */}
        {venueLayout.gates.map((g) => {
          const isExit = routeDef?.exitGate === g.id;
          return (
            <g key={g.id}>
              <circle
                cx={g.x}
                cy={g.y}
                r={isExit ? 12 : 9}
                fill={g.status === "open" ? "#2dd4bf" : "#ef4444"}
                stroke={isExit ? "#39ff88" : "#0b0f1a"}
                strokeWidth={isExit ? 3 : 1.5}
                className={isExit ? "gate-pulse" : ""}
              />
              <text
                x={g.x}
                y={g.y - 14}
                fill="#9fb3c8"
                fontSize="10"
                fontFamily="JetBrains Mono, monospace"
                textAnchor="middle"
              >
                {g.id.replace("Gate ", "G")}
              </text>
            </g>
          );
        })}
      </svg>

      <div className="venue-legend">
        <span><i className="dot dot-low" /> Low Activity</span>
        <span><i className="dot dot-med" /> Caution</span>
        <span><i className="dot dot-high" /> High Risk</span>
        <span><i className="dot dot-gate" /> Gate</span>
        <span><i className="dot dot-route" /> Rescue Route</span>
      </div>

      <style>{`
        .venue-map-wrapper {
          background: #11151f;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 14px;
          padding: 14px;
          color: #e6edf3;
          font-family: 'Inter', sans-serif;
        }
        .venue-map-header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 10px;
          flex-wrap: wrap;
          gap: 8px;
        }
        .venue-title { font-weight: 600; font-size: 15px; }
        .danger-badge {
          background: rgba(255,59,59,0.15);
          color: #ff6b6b;
          border: 1px solid rgba(255,59,59,0.4);
          padding: 4px 10px;
          border-radius: 999px;
          font-size: 12px;
          font-family: 'JetBrains Mono', monospace;
          animation: blink 1.2s infinite;
        }
        .venue-svg { width: 100%; height: auto; border-radius: 10px; display: block; }
        .venue-legend {
          display: flex;
          gap: 14px;
          flex-wrap: wrap;
          margin-top: 10px;
          font-size: 11px;
          color: #9fb3c8;
        }
        .dot {
          display: inline-block;
          width: 10px; height: 10px;
          border-radius: 50%;
          margin-right: 5px;
          vertical-align: middle;
        }
        .dot-low { background: rgb(30,60,200); }
        .dot-med { background: rgb(255,220,40); }
        .dot-high { background: rgb(255,40,40); }
        .dot-gate { background: #2dd4bf; }
        .dot-route { background: #39ff88; }

        .cell-pulse {
          animation: cellPulse 1s infinite ease-in-out;
        }
        @keyframes cellPulse {
          0%, 100% { opacity: 0.6; }
          50% { opacity: 1; }
        }
        .danger-glow {
          filter: drop-shadow(0 0 6px #ff3b3b);
          animation: glowPulse 1.2s infinite ease-in-out;
        }
        @keyframes glowPulse {
          0%, 100% { stroke-opacity: 0.6; }
          50% { stroke-opacity: 1; }
        }
        .route-dash {
          animation: dashMove 1.5s linear infinite;
        }
        @keyframes dashMove {
          to { stroke-dashoffset: -32; }
        }
        .gate-pulse {
          animation: glowPulse 1s infinite ease-in-out;
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.3; }
        }
      `}</style>
    </div>
  );
}
