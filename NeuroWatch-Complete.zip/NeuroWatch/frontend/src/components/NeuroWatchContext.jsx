import React, { createContext, useContext } from "react";
import { useNeuroWatchData } from "./useNeuroWatchData";

const NeuroWatchContext = createContext(null);

export function NeuroWatchProvider({ children, initialScenario = "normal" }) {
  const value = useNeuroWatchData(initialScenario);
  return (
    <NeuroWatchContext.Provider value={value}>
      {children}
    </NeuroWatchContext.Provider>
  );
}

export function useNeuroWatch() {
  const ctx = useContext(NeuroWatchContext);
  if (!ctx) {
    throw new Error("useNeuroWatch must be used within a NeuroWatchProvider");
  }
  return ctx;
}
