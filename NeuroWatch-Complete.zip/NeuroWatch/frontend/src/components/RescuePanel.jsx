import React from "react";
import venueLayout from "../../../data/venue_layout.json";

/**
 * RescuePanel.jsx
 * Props:
 *  - rescue: {
 *      status: "SAFE" | "CAUTION" | "WARNING" | "HIGH RISK" | "EMERGENCY",
 *      action: string,
 *      zone: string,
 *      route: "A" | "B" | "C",
 *      exitGate: string,
 *      officers: number,
 *      announcement: string
 *    }
 *  - victim: { zone: string, confidence: number } | null
 */

const STATUS_STYLES = {
  SAFE:       { color: "#39ff88", bg: "rgba(57,255,136,0.1)",  icon: "✅" },
  CAUTION:    { color: "#ffd93d", bg: "rgba(255,217,61,0.1)",  icon: "⚠️" },
  WARNING:    { color: "#ff9f1c", bg: "rgba(255,159,28,0.12)", icon: "🟠" },
  "HIGH RISK":{ color: "#ff5050", bg: "rgba(255,80,80,0.12)",  icon: "🔴" },
  EMERGENCY:  { color: "#ff1f3d", bg: "rgba(255,31,61,0.18)",  icon: "🚨" },
};

export default function RescuePanel({ rescue, victim }) {
  const status = rescue?.status || "SAFE";
  const style = STATUS_STYLES[status] || STATUS_STYLES.SAFE;
  const routeDef = rescue?.route ? venueLayout.routes[rescue.route] : null;

  return (
    <div className="rescue-panel">
      <div className="rescue-header" style={{ borderColor: style.color }}>
        <span className="rescue-icon">{style.icon}</span>
        <div>
          <div className="rescue-status" style={{ color: style.color }}>
            {status}
          </div>
          <div className="rescue-subtitle">Rescue & Response Plan</div>
        </div>
      </div>

      <div className="rescue-body">
        <div className="rescue-row">
          <span className="label">Recommended Action</span>
          <span className="value">
            {rescue?.action || "Monitor — no action required"}
          </span>
        </div>

        <div className="rescue-row">
          <span className="label">Danger Zone</span>
          <span className="value zone-tag">
            {rescue?.zone || "—"}
          </span>
        </div>

        <div className="rescue-row">
          <span className="label">Evacuation Route</span>
          <span className="value">
            {routeDef ? `Route ${rescue.route} → ${routeDef.exitGate}` : "—"}
          </span>
        </div>

        {routeDef && (
          <div className="route-desc">{routeDef.description}</div>
        )}

        <div className="rescue-row">
          <span className="label">Officers Deployed</span>
          <span className="value officer-count">
            👮 {rescue?.officers ?? 0}
          </span>
        </div>

        {victim && (
          <div className="victim-card">
            <div className="victim-header">
              <span className="victim-icon">🆘</span>
              <span>Possible Victim Detected</span>
            </div>
            <div className="victim-details">
              <span>Zone: <b>{victim.zone}</b></span>
              <span>Confidence: <b>{(victim.confidence * 100).toFixed(0)}%</b></span>
            </div>
          </div>
        )}

        {rescue?.announcement && status !== "SAFE" && (
          <div className="announcement-box">
            <div className="announcement-label">📢 Public Announcement</div>
            <div className="announcement-text">{rescue.announcement}</div>
          </div>
        )}
      </div>

      <style>{`
        .rescue-panel {
          background: #11151f;
          border: 1px solid rgba(255,255,255,0.08);
          border-radius: 14px;
          padding: 14px;
          color: #e6edf3;
          font-family: 'Inter', sans-serif;
        }
        .rescue-header {
          display: flex;
          align-items: center;
          gap: 12px;
          padding-bottom: 10px;
          border-bottom: 1px solid;
          margin-bottom: 12px;
        }
        .rescue-icon { font-size: 28px; }
        .rescue-status {
          font-family: 'JetBrains Mono', monospace;
          font-size: 18px;
          font-weight: 700;
          letter-spacing: 1px;
        }
        .rescue-subtitle {
          font-size: 11px;
          color: #9fb3c8;
          margin-top: 2px;
        }
        .rescue-row {
          display: flex;
          justify-content: space-between;
          align-items: center;
          padding: 6px 0;
          font-size: 13px;
          border-bottom: 1px solid rgba(255,255,255,0.04);
        }
        .label { color: #9fb3c8; }
        .value { font-weight: 600; text-align: right; }
        .zone-tag {
          font-family: 'JetBrains Mono', monospace;
          background: rgba(255,255,255,0.06);
          padding: 2px 8px;
          border-radius: 6px;
        }
        .route-desc {
          font-size: 12px;
          color: #9fb3c8;
          font-style: italic;
          padding: 4px 0 6px 0;
        }
        .officer-count { font-size: 14px; }
        .victim-card {
          margin-top: 12px;
          background: rgba(255,31,61,0.1);
          border: 1px solid rgba(255,31,61,0.35);
          border-radius: 10px;
          padding: 10px;
          animation: blink 1.4s infinite;
        }
        .victim-header {
          font-weight: 700;
          color: #ff5050;
          display: flex;
          gap: 8px;
          align-items: center;
          margin-bottom: 6px;
          font-size: 13px;
        }
        .victim-details {
          display: flex;
          justify-content: space-between;
          font-size: 12px;
          color: #e6edf3;
        }
        .announcement-box {
          margin-top: 12px;
          background: rgba(255,159,28,0.1);
          border: 1px solid rgba(255,159,28,0.3);
          border-radius: 10px;
          padding: 10px;
        }
        .announcement-label {
          font-size: 11px;
          color: #ff9f1c;
          font-weight: 600;
          margin-bottom: 4px;
        }
        .announcement-text {
          font-size: 13px;
          line-height: 1.4;
        }
        @keyframes blink {
          0%, 100% { opacity: 1; }
          50% { opacity: 0.55; }
        }
      `}</style>
    </div>
  );
}
