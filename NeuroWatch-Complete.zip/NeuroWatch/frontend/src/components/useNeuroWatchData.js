import { useState, useEffect, useRef, useCallback } from "react";
import { io } from "socket.io-client";
import { getMockData } from "./mockData";

const BACKEND_URL = "http://localhost:5000";

/**
 * useNeuroWatchData
 * Connects to the NeuroWatch backend via Socket.IO. If the backend
 * is unreachable (e.g. running the frontend standalone for demo/dev),
 * falls back to generating mock data locally every 800ms so the UI
 * remains fully interactive.
 *
 * Returns:
 *  {
 *    data,            // latest payload (spikeGrid, risk, status, rescue, victim, alert)
 *    scenario,        // current scenario string
 *    setScenario,     // (name) => void
 *    connected,       // boolean - true if live backend connected
 *    alerts,          // array of alert log entries (newest first)
 *    clearAlerts      // () => void
 *  }
 */
export function useNeuroWatchData(initialScenario = "normal") {
  const [scenario, setScenarioState] = useState(initialScenario);
  const [data, setData] = useState(() => mockToPayload(getMockData(initialScenario), initialScenario, 0));
  const [connected, setConnected] = useState(false);
  const [alerts, setAlerts] = useState([]);

  const socketRef = useRef(null);
  const mockIntervalRef = useRef(null);
  const alertSeqRef = useRef(0);

  const pushAlert = useCallback((payload) => {
    if (!payload?.alert) return;
    setAlerts((prev) => [payload.alert, ...prev].slice(0, 100));
  }, []);

  // --- Try real backend via Socket.IO ---
  useEffect(() => {
    const socket = io(BACKEND_URL, {
      transports: ["websocket", "polling"],
      reconnectionAttempts: 3,
      timeout: 2000,
    });
    socketRef.current = socket;

    socket.on("connect", () => {
      setConnected(true);
      socket.emit("set_scenario", { scenario });
    });

    socket.on("update", (payload) => {
      setData(payload);
      pushAlert(payload);
    });

    socket.on("connect_error", () => {
      setConnected(false);
    });

    socket.on("disconnect", () => {
      setConnected(false);
    });

    return () => {
      socket.disconnect();
    };
  }, []); // eslint-disable-line

  // --- Mock fallback loop (only runs when not connected) ---
  useEffect(() => {
    if (connected) {
      if (mockIntervalRef.current) {
        clearInterval(mockIntervalRef.current);
        mockIntervalRef.current = null;
      }
      return;
    }

    const tick = () => {
      alertSeqRef.current += 1;
      const payload = mockToPayload(getMockData(scenario), scenario, alertSeqRef.current);
      setData(payload);
      pushAlert(payload);
    };

    tick(); // immediate first tick on scenario change
    mockIntervalRef.current = setInterval(tick, 800);

    return () => {
      if (mockIntervalRef.current) clearInterval(mockIntervalRef.current);
    };
  }, [scenario, connected, pushAlert]);

  const setScenario = useCallback((name) => {
    setScenarioState(name);
    if (socketRef.current && connected) {
      socketRef.current.emit("set_scenario", { scenario: name });
    }
  }, [connected]);

  const clearAlerts = useCallback(() => setAlerts([]), []);

  return { data, scenario, setScenario, connected, alerts, clearAlerts };
}

/**
 * Converts mockData.js output into the same payload shape the real
 * backend emits over Socket.IO, including a synthetic alert entry.
 */
function mockToPayload(mock, scenario, seq) {
  const now = new Date();
  const timestamp = now.toTimeString().slice(0, 8);

  const status = mock.status;
  const rescue = mock.rescue || {
    status,
    action: "Monitor — no action required",
    zone: null,
    route: null,
    officers: 2,
    announcement: "",
  };

  return {
    scenario,
    timestamp,
    spikeGrid: mock.spikeGrid,
    spikeDensity: Number((mock.risk / 100).toFixed(3)),
    flowVariance: Number((mock.risk / 130).toFixed(3)),
    spikeRate: Number((mock.risk / 140).toFixed(3)),
    risk: mock.risk,
    status,
    dangerZone: mock.dangerZone,
    victim: mock.victim,
    rescue,
    alert: {
      id: `mock-${seq}`,
      timestamp,
      risk: mock.risk,
      zone: rescue.zone,
      status,
      message: rescue.action,
    },
  };
}
