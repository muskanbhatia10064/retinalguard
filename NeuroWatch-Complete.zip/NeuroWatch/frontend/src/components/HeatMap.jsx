import React from "react";

/**
 * HeatMap.jsx
 * 10x10 grid of cells colored blue -> yellow -> red based on
 * spike intensity. Cells pulse when intensity > 0.7.
 *
 * Props:
 *  - grid: 10x10 array of numbers in [0,1]
 */

function intensityToColor(v) {
  if (v < 0.5) {
    const t = v / 0.5;
    const r = Math.round(30 + t * (255 - 30));
    const g = Math.round(60 + t * (220 - 60));
    const b = Math.round(200 - t * 160);
    return `rgb(${r},${g},${b})`;
  } else {
    const t = (v - 0.5) / 0.5;
    const r = 255;
    const g = Math.round(220 - t * 220);
    const b = Math.round(40 - t * 40);
    return `rgb(${r},${g},${b})`;
  }
}

export default function HeatMap({ grid }) {
  const data = grid && grid.length === 10
    ? grid
    : Array.from({ length: 10 }, () => Array.from({ length: 10 }, () => 0));

  return (
    <div className="heatmap card">
      <div className="heatmap-header">
        <span className="heatmap-title">🔥 Spike Intensity Heatmap</span>
        <span className="heatmap-sub">10×10 neuromorphic event grid</span>
      </div>
      <div className="heatmap-grid">
        {data.map((row, r) =>
          row.map((val, c) => (
            <div
              key={`${r}-${c}`}
              className={`heatmap-cell ${val > 0.7 ? "pulse" : ""}`}
              style={{
                background: intensityToColor(val),
                opacity: 0.35 + val * 0.55,
              }}
              title={`(${r},${c}): ${val.toFixed(2)}`}
            />
          ))
        )}
      </div>

      <style>{`
        .heatmap {
          color: var(--text-primary);
          font-family: var(--font-ui);
        }
        .heatmap-header {
          display: flex;
          justify-content: space-between;
          align-items: baseline;
          margin-bottom: 10px;
          flex-wrap: wrap;
          gap: 6px;
        }
        .heatmap-title { font-weight: 600; font-size: 15px; }
        .heatmap-sub { font-size: 11px; color: var(--text-secondary); font-family: var(--font-mono); }
        .heatmap-grid {
          display: grid;
          grid-template-columns: repeat(10, 1fr);
          gap: 3px;
          aspect-ratio: 1;
        }
        .heatmap-cell {
          border-radius: 3px;
          transition: background 0.3s, opacity 0.3s;
        }
        .heatmap-cell.pulse {
          animation: cellPulse 1s infinite ease-in-out;
        }
        @keyframes cellPulse {
          0%, 100% { opacity: 0.6; transform: scale(1); }
          50% { opacity: 1; transform: scale(1.05); }
        }
      `}</style>
    </div>
  );
}
