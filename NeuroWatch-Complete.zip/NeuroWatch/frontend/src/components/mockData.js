/**
 * mockData.js
 * Generates fake spike grid + rescue data for the 3 scenarios.
 * Used by useNeuroWatchData.js as a "Simulation Mode" fallback when
 * the real Flask/Socket.IO backend (app.py) isn't reachable, so the
 * full frontend remains demo-able standalone.
 */

function emptyGrid(base = 0.03) {
  return Array.from({ length: 10 }, () =>
    Array.from({ length: 10 }, () => base + Math.random() * 0.03)
  );
}

export function getMockData(scenario) {
  const grid = emptyGrid();

  if (scenario === "normal") {
    return {
      spikeGrid: grid,
      risk: 15 + Math.round(Math.random() * 10),
      status: "SAFE",
      dangerZone: null,
      victim: null,
      rescue: {
        status: "SAFE",
        action: "Monitor — no action required",
        zone: null,
        route: null,
        officers: 2,
        announcement: "",
      },
    };
  }

  if (scenario === "kumbh_surge") {
    for (let r = 2; r <= 3; r++) {
      for (let c = 3; c <= 4; c++) {
        grid[r][c] = 0.65 + Math.random() * 0.3;
      }
    }
    for (let r = 1; r <= 2; r++) {
      for (let c = 2; c <= 3; c++) {
        grid[r][c] = Math.max(grid[r][c], 0.35 + Math.random() * 0.2);
      }
    }
    return {
      spikeGrid: grid,
      risk: 50 + Math.round(Math.random() * 12),
      status: "WARNING",
      dangerZone: "C3",
      victim: null,
      rescue: {
        status: "WARNING",
        action: "Increase crowd control near C3; prepare evacuation Route B",
        zone: "C3",
        route: "B",
        officers: 6,
        announcement:
          "Attention: Crowd density rising in the venue. Please move calmly toward designated exits and follow staff instructions.",
      },
    };
  }

  if (scenario === "crush") {
    for (let r = 2; r <= 4; r++) {
      for (let c = 3; c <= 5; c++) {
        grid[r][c] = 0.78 + Math.random() * 0.2;
      }
    }
    grid[3][4] = 0.95 + Math.random() * 0.05; // C4 peak
    grid[4][5] = 0.05 + Math.random() * 0.1;  // D5 low-motion victim signature

    return {
      spikeGrid: grid,
      risk: 88 + Math.round(Math.random() * 10),
      status: "EMERGENCY",
      dangerZone: "C4",
      victim: { zone: "D5", confidence: 0.22 + Math.random() * 0.1 },
      rescue: {
        status: "EMERGENCY",
        action: "IMMEDIATE EVACUATION — deploy all available units to C4, Route C",
        zone: "C4",
        route: "C",
        officers: 14,
        announcement:
          "EMERGENCY: Please move away from the danger zone immediately and proceed to the Emergency Exit. Follow officer instructions and remain calm.",
      },
    };
  }

  return { spikeGrid: grid, risk: 0, status: "SAFE", dangerZone: null, victim: null, rescue: null };
}

export const SCENARIOS = ["normal", "kumbh_surge", "crush"];
