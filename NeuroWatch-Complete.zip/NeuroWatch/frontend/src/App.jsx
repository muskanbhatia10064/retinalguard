import React from "react";
import { HashRouter, Routes, Route, Link, useLocation } from "react-router-dom";
import Dashboard from "./pages/Dashboard";
import AlertsPage from "./pages/AlertsPage";
import { NeuroWatchProvider, useNeuroWatch } from "./components/NeuroWatchContext";

function NavBar() {
  const location = useLocation();
  return (
    <nav className="navbar">
      <Link to="/" className={`nav-link ${location.pathname === "/" ? "active" : ""}`}>
        Dashboard
      </Link>
      <Link to="/alerts" className={`nav-link ${location.pathname === "/alerts" ? "active" : ""}`}>
        Alert History
      </Link>

      <style>{`
        .navbar {
          display: flex;
          gap: 4px;
          padding: 10px 20px 0 20px;
          max-width: 1400px;
          margin: 0 auto;
        }
        .nav-link {
          color: var(--text-secondary);
          font-size: 13px;
          font-weight: 600;
          padding: 8px 16px;
          border-radius: 8px 8px 0 0;
          transition: all 0.15s;
        }
        .nav-link:hover { color: var(--text-primary); }
        .nav-link.active {
          color: var(--color-safe);
          background: var(--bg-panel);
        }
      `}</style>
    </nav>
  );
}

function AlertsPageWrapper() {
  const { alerts, clearAlerts } = useNeuroWatch();
  return <AlertsPage alerts={alerts} onClear={clearAlerts} />;
}

export default function App() {
  return (
    <NeuroWatchProvider initialScenario="normal">
      <HashRouter>
        <NavBar />
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/alerts" element={<AlertsPageWrapper />} />
        </Routes>
      </HashRouter>
    </NeuroWatchProvider>
  );
}
